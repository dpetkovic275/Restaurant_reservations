import React from 'react';
import { View, Text, StyleSheet, Image} from 'react-native';
import { useNavigation } from '@react-navigation/native'; // Import useNavigation

const ZahvalaEkran = () => {
  const navigation = useNavigation(); // Get the navigation object
  return (
    <View style={stil.ekran}>
      <Image
        source={require('../assets/signboard.png')}
        style={stil.image}
      />
      <Text style={stil.zahvalaTekst}>Hvala na vašoj rezervaciji!</Text>
    </View>
  );
};

const stil = StyleSheet.create({
  image: {
    width: '100%',
    height: '50%',
    resizeMode: 'cover',
    zIndex: 0,
  },
  ekran: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e0ebeb',
  },

  zahvalaTekst: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
    marginBottom: 10,
    fontFamily:'ProstestRiot'
  },

});

export default ZahvalaEkran;
