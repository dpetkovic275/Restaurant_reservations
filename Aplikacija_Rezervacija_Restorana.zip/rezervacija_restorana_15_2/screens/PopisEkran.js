import React, { useState } from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';

import ListaElement from '../components/ListaElement';
import { useSelector } from 'react-redux';

const PopisEkran = ({ route, navigation }) => {
  const prikaz = route.params.prikaz;
  const radoviPrikaz = useSelector((state) => {
    if (prikaz === 'svi') {
      return state.radovi.filterRadovi;
    } else if (prikaz === 'fav') {
      return state.radovi.favoritRadovi;
    }
    return null;
  });

  const prikazElelementa = (podaci) => {
    return (
      <ListaElement
        onPress={() => navigation.navigate('Detalji', { id: podaci.item.id })}
        natpis={podaci.item.student}
      />
    );
  };

  const [searchText, setSearchText] = useState('');
  const data = radoviPrikaz;

  const filteredData = data.filter((item) =>
    item.student.toLowerCase().includes(searchText.toLowerCase())
  );

  const searchFilterFunction = (text) => {
    setSearchText(text);
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={stil.ekran}>
        <View style={{ flex: 1, padding: 20 ,alignItems: 'center'}}>
          <TextInput
            style={stil.searchBar}
            placeholder="Pretraži po imenu"
            placeholderTextColor="black" 
            onChangeText={searchFilterFunction}
            value={searchText}
          />
          <View style={stil.lista}>
            <FlatList
              showsVerticalScrollIndicator={false}
              style={{ margin: 5 }}
              data={filteredData}
              renderItem={prikazElelementa}
              keyExtractor={(item) => item.id}
              numColumns={1}
            />
          </View>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};

const stil = StyleSheet.create({
  ekran: {
    width: '100%',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e0ebeb',
  },
  lista: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
  },
  searchBar: {
    width: 250,
    padding: 10,
    borderRadius: 50,
    backgroundColor: '#f0f0f0',
    marginBottom: 10,
    borderColor: 'gray', 
    borderWidth: 1
  },
});

export default PopisEkran;