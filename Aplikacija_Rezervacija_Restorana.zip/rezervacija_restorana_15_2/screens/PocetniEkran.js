import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking } from 'react-native';
import Tipka from '../components/Tipka'
import Modal from 'react-native-modal'; 

const contactIcon = require('../assets/contacts.png');
const PocetniEkran = ({navigation}) => {
  const [isModalVisible, setIsModalVisible] = React.useState(false);

  const showModal = () => {
    setIsModalVisible(true);
  };

  const hideModal = () => {
    setIsModalVisible(false);
  };
  const openMaps = () => {
  const address = '1061 Budapest, Király st. 26.';
  const formattedAddress = address.replace(/\s+/g, '+');
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${formattedAddress}`;

  Linking.openURL(mapsUrl);
};
  return (
    <View style={stil.ekran}>
      <Image style={stil.slika} source={require('../assets/restoran.jpg')} />
        <View style={[stil.container, {backgroundColor: 'transparent'}]} >
        <TouchableOpacity onPress={showModal}>
          <Image source={contactIcon} style={stil.contactIcon} />
        </TouchableOpacity>
      </View>
      <View style={stil.naslovContainer}>
        <Text style={stil.naslov}>TwentySix</Text>
        <Text style={stil.podnaslov}>THE GREENEST RESTAURANT IN HUNGARY</Text>
      </View>
      <View style={stil.tipke}>
        <Tipka
          title="REZERVIRAJ"
          onPress={() => {
            navigation.navigate('Unos');
          }}
        />
        <Tipka
          title="POPIS"
          onPress={() => {
            navigation.navigate('Popis');
          }}
        />
      </View>

      <Modal isVisible={isModalVisible} onBackdropPress={hideModal}>
        <View style={stil.modalContent}>
          <Text style={stil.naslov}>DETALJI </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}>
              <Image source={require('../assets/gmail.png')} style={stil.contactIcon} />
              <Text style={stil.contactText}>info@twentysixrestaurant.com</Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}>
              <Image source={require('../assets/phone.png')} style={stil.contactIcon} />
              <Text style={stil.contactText}>36 1 123 4567</Text>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}>
              <Image source={require('../assets/wall-clock.png')} style={stil.contactIcon} />
              <Text style={stil.contactText}>9:00 - 23:00</Text>
          </View>
          <TouchableOpacity style= { {flexDirection: 'row', alignItems: 'center', marginVertical: 5 }}onPress=    {openMaps}>
              <Image source={require('../assets/location.png')} style={stil.contactIcon} />
              <Text style={stil.contactText}>1061 Budapest, Király st. 26.</Text>
          </TouchableOpacity>

          <Tipka title="Zatvori" onPress={hideModal} />
        </View>
      </Modal>
    </View>
  )
}

const stil = StyleSheet.create({
  ekran: {
    flex: 1,
    alignItems: "center",
  },
  naslovContainer: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 1,
  },
  naslov: {
    fontSize: 60,
    marginVertical: 10,
    textAlign:'left',
    color:"#ffffff",
    fontFamily:'ProstestStrike',

  },
  podnaslov: {
    fontSize: 22,
    marginVertical: 10,
    color:"#ffffff",
    fontFamily:'ProstestRiot',

  },
  tipke: {
    flexDirection: "row",
    paddingHorizontal: 145,
    bottom: 100,
    zIndex: 1,
  },
  slika: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    zIndex: 0,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    bottom: 160,
  },
  contactIcon: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
  

  contactText: {
    color: '#fff',
    fontSize: 22,
    fontFamily:'ProstestRiot',

  },
  modalContent: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
    padding: 20,
  },
});

export default PocetniEkran;