import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Keyboard,
  TouchableWithoutFeedback,
  TouchableOpacity,
  Modal
} from 'react-native';

import Tipka from '../components/Tipka';
import Rad from '../models/rad';
import { RADOVI } from '../data/test-podaci';
import DatePicker from 'react-native-modern-datepicker';
import { getFormatedDate } from 'react-native-modern-datepicker';
import RNPickerSelect from 'react-native-picker-select';


const UnosEkran = ({ navigation }) => {
  const [ime, postaviIme] = useState('');
  const [broj, postaviBroj] = useState('');
  const [email, setEmail] = useState('');
  const [kontakt, postaviKontakt]=useState('')

  const [openDatePicker, setOpenDatePicker] = useState(false);
  const today = new Date();
  const startDate = getFormatedDate(
    today.setDate(today.getDate() + 1),
    'YYYY/MM/DD'
  );
  const [selectedDate, setSelectedDate] = useState('');
  const [pickedDate, setPickedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  const changeIme = (tekst) => {
    postaviIme(tekst);
  };

  const changeBroj = (tekst) => {
    postaviBroj(tekst);
  };

  const changeKontakt = (tekst) => {
    postaviKontakt(tekst);
  };
  const changeEmail = (text) => {
    setEmail(text);
  };
  const showDatePicker = () => {
    setOpenDatePicker(true);
  };

  const hideDatePicker = () => {
    setOpenDatePicker(false);
  };

  const handleConfirm = (date) => {
    setSelectedDate(date);
    hideDatePicker();
  };
 
  useEffect(() => {
    navigation.setOptions(({
      headerRight: () => {
        return (
          <TouchableOpacity onPress={() => navigation.push('Popis')}>
          </TouchableOpacity>
        );
      },
    }));
  }, [navigation]);



  const changeTime = (time) => {
    setSelectedTime(time);
  };

  const dodajNovi = () => {
    if (ime === '' || broj === '' || selectedTime === '') {
      return;
    } else {
      const novi = new Rad(
        RADOVI.length,
        ime,
        broj,
        email,
        kontakt,
        selectedDate,
        selectedTime,


      );
      postaviIme('');
      postaviBroj('');
      setEmail('');
      postaviKontakt('');
      hideDatePicker();
      setSelectedTime('');
      Keyboard.dismiss();
      RADOVI.push(novi);

    }
  };
  

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={stil.ekran}>
        <Text style={stil.detaljiTekst}>Ispuni podatke za rezervaciju</Text> 
        <View style={stil.inputField}>
          <Text style={stil.tekst}>Ime i prezime:</Text>
          <TextInput
            style={stil.txtInput}
            value={ime}
            onChangeText={changeIme}
          />
        </View>
        <View style={stil.inputField}>
          <Text style={stil.tekst}>Broj osoba:</Text>
          <TextInput
            style={stil.txtInput}
            value={broj}
            onChangeText={changeBroj}
            keyboardType="numeric"
          />
        </View>
        <View style={stil.inputField}>
          <Text style={stil.tekst}>Email:</Text>
          <TextInput
            style={stil.txtInput}
            value={email}
            onChangeText={changeEmail}
            keyboardType="email-address"
          />
        </View>
        <View style={stil.inputField}>
          <Text style={stil.tekst}>Kontakt broj:</Text>
          <TextInput
            style={stil.txtInput}
            value={kontakt}
            onChangeText={changeKontakt}
            keyboardType="numeric"
          />
        </View>
        <View style={stil.picker} >
          <Text style={stil.tekst}>Vrijeme:</Text>
          <RNPickerSelect
            value={selectedTime}
            onValueChange={(itemValue) => changeTime(itemValue)}
            items={Array.from({ length: 14 }, (_, index) => ({
              label: `${index + 9}:00 ${index + 9 < 12 ? 'AM' : 'PM'}`,
              value: `${index + 9}:00 ${index + 9 < 12 ? 'AM' : 'PM'}`,
            }))}
          />
        </View>
        <View>
          <Tipka title="Odaberi datum" onPress={showDatePicker} />
          <Modal
            animationType="slide"
            visible={openDatePicker}>
            <View style={stil.centeredView}>
              <View style={stil.modalView}>
                <DatePicker
                  mode="calendar"
                  minimumDate={startDate}
                  selected={pickedDate}
                  onDateChanged={handleConfirm}
                  onSelectedChange={(date) => setSelectedDate(date)}
                />
                <TouchableOpacity onPress={hideDatePicker}>
                  <Text style={{ color: 'black' }}>Zatvori</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </View>
        <View>
          <Tipka
            title="Spremi"
            style={{
              marginTop: 20,
              width: 300,
              height: 50,
            }}
            onPress={() => {
              dodajNovi();
              navigation.navigate('Zahvala'); // Navigate to ZahvalaEkran
            }}
          ></Tipka>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};


const stil = StyleSheet.create({
  ekran: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e0ebeb',
  },
  txtInput: {
    height: 38,
    width: 250,
    borderWidth: 1,
    padding: 10,
    color: 'black',
    borderColor: 'black',
    borderRadius: 5,
    backgroundColor: 'white',
  },
  inputField: {
    margin: 13,
  },
  tekst: {
    color: 'black',
  },
  centeredView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalView: {
    margin: 20,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    padding: 35,
    width: '90%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  picker:{
    width: 250,
    height:60,
  },
  detaljiTekst: {
    color: 'black',
    fontSize: 22,
    marginBottom:5,

  },


});

export default UnosEkran;