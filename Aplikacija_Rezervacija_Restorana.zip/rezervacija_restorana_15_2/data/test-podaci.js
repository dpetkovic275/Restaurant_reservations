import Rad from '../models/rad'

export const RADOVI = [
  new Rad(0, "Ana Anić", "5",'anaanic@gmail.com','0958251226','2024/04/23','12:00'),
  new Rad(1, "Mihael Matić","3", 'mihaelmatic@gmail.com','0936585748', '2024/04/23','12:00'),
  new Rad(2, "Matilda Turić","3",'matildat@gmail.com','0956363524','2024/04/23','12:00',),
  new Rad(3, "Petra Čolak","5", 'petrac@gmail.com','0925656589','2024/04/23','12:00')

]