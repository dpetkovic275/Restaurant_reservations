class Rad {
  constructor(id, student, broj, email, kontakt,datumod,vrijeme){
    this.id = id
    this.student = student;
    this.broj = broj;
    this.email=email;
    this.kontakt=kontakt;
    this.datumod=datumod;
    this.vrijeme=vrijeme;
  }
}

export default Rad